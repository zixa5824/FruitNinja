This directory should have these 3:

1- FruitNinja.jar
2- resources folder, for images
3- music folder, for sounds