package utilities;

public interface Command {

    void execute() ;


    void unexecute() ;

}

