package GameModes;

import SliceableObjects.ISliceableObject;

import java.util.List;

public abstract class DifficultyDecorator implements IGameModeStrategy {

    protected IGameModeStrategy gameMode;


}
