Bishoy Refaat Riad: GUI, Factory, Strategy and Game Mode logic, controller, Command with Saving and loading

Karim M. Elsayad: GUI, Game objects, moving, and slicing, Controller, Decorators and difficulties, sounds

Mahmoud Sharshera: Major GUI and overall design, score board, saving and loading, sounds

Mohannad Ayman: GUI, sounds


The game directoy should have these 3:

1- FruitNinja.jar
2- resources folder, for images
3- music folder, for sounds

It woun't run without any of them